#for standalone
cp -rf share/ofMaker /usr/share/ofMaker
cp -f bin/ofMaker /usr/bin

#for codelite
cp -rf share/ofMaker /usr/share/codelite
cp -f lib/codelite/OfProjectMaker.so /usr/lib/codelite
