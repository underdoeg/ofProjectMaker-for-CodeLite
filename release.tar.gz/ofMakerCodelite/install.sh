cp -rf share/ofMaker /usr/share
cp -f bin/ofMaker /usr/bin
